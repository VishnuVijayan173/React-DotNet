﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Domain.Entities
{
    public class ProjectAllocation
    {
        [Key]
        public Guid AllocationID { get; set; }

        public Guid ProjectID { get; set; }

        public Guid UserID { get; set; }
        public DateTime UpdatedOn { get; set; }

        public string UpdatedBy { get; set; }
    }
}
