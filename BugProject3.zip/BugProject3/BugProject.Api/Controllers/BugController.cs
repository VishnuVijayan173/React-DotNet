﻿using Microsoft.AspNetCore.Mvc;
using BugProject.Domain.Repositories;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using System.Data;
using BugProject.Infrastructure.Persistence.DTO;
using BugProject.Domain.Entities;
using BugProject.Application.Common.Logger;
using BugProject.Application.Common.Interfaces;

namespace BugProject.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class BugController : Controller
    {
        private readonly IBugService bugService;
        private readonly IMapper mapper;
        private readonly ILoggerManager _logger;
      

        public BugController(IBugService bugService, IMapper mapper, ILoggerManager logger)
        {
            this.bugService = bugService;
            this.mapper = mapper;
            this._logger = logger;
            
        }
        [HttpGet]
       
        public async Task<IActionResult> GetAllBugsAsync()
        {
            try
            {
                var bugs = await bugService.GetAllAsync();
                var bugsDTO = new List<Infrastructure.Persistence.DTO.Bug>();
                bugs.ToList().ForEach(bug =>
                {
                    var bugDTO = new Infrastructure.Persistence.DTO.Bug()
                    {
                        BugID = bug.BugID,
                        BugName = bug.BugName,
                        BugDescription = bug.BugDescription,
                        CreatedOn = bug.CreatedOn,
                        UpdatedOn = bug.UpdatedOn,

                    };
                    bugsDTO.Add(bugDTO);
                    _logger.LogInfo($"{bugsDTO.Count}Bugs Retrieved ");
                });
                return Ok(bugsDTO);
            }


            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpGet]
        [Route("{id:guid}")]
        [ActionName("GetBugAsync")]
        public async Task<IActionResult> GetBugAsync(Guid id)
        {
            try
            {
                var bug = await bugService.GetAsync(id);

                if (bug == null)
                {
                    _logger.LogInfo("The recod was not found ");
                    return NotFound();
                }

                var bugs = await bugService.GetAllAsync();
                var bugsDTO = new List<Infrastructure.Persistence.DTO.Bug>();
                bugs.ToList().ForEach(bug =>
                {
                    if (bug.BugID == id)
                    {
                        var bugDTO = new Infrastructure.Persistence.DTO.Bug()
                        {
                            BugID = bug.BugID,
                            BugName = bug.BugName,
                            BugDescription = bug.BugDescription,
                            CreatedOn = bug.CreatedOn,
                            UpdatedOn = bug.UpdatedOn,

                        };
                        bugsDTO.Add(bugDTO);
                        _logger.LogInfo("Bug Retrieved with id ");
                    }
                });
                
                return Ok(bugsDTO);
            }
            catch(Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        
        public async Task<IActionResult> AddBugAsync(Infrastructure.Persistence.DTO.AddBugRequest addBugRequest)
        {
            try
            {
                
                
                var bug = new Domain.Entities.Bug()
                {
                    BugName = addBugRequest.BugName,
                    BugDescription = addBugRequest.BugDescription,
                    
                    CreatedOn = addBugRequest.CreatedOn,


                    UpdatedOn = addBugRequest.UpdatedOn,
                };

                
                // Pass details to Service
                bug = await bugService.AddAsync(bug);

                // Convert back to DTO

                var bugDTO = new Infrastructure.Persistence.DTO.Bug
                {
                    BugID = bug.BugID,
                    BugName = bug.BugName,
                    BugDescription = bug.BugDescription,

                    CreatedOn = bug.CreatedOn,

                    UpdatedOn = bug.UpdatedOn,
                };
                _logger.LogInfo("Bug Added ");
                
                return Ok(CreatedAtAction(nameof(GetBugAsync), new { id = bugDTO.BugID }, bugDTO));
            }
            catch(Exception ex)
            {
                
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
            
        }
        [HttpDelete]
        [Route("{id:guid}")]
        
        public async Task<IActionResult> DeleteBugAsync(Guid id)
        {
            try
            {
                // Get Bug from database
                var bug = await bugService.DeleteAsync(id);

                // If null NotFound
                if (bug == null)
                {
                    return NotFound();
                }

                // Convert response back to DTO
                var bugDTO = new Infrastructure.Persistence.DTO.Bug
                {
                    BugID = bug.BugID,
                    BugName = bug.BugName,
                    BugDescription = bug.BugDescription,

                    CreatedOn = bug.CreatedOn,

                    UpdatedOn = bug.UpdatedOn,
                };


                // return Ok response
                _logger.LogInfo("Bug Deleted ");
                
                return Ok(bugDTO);
            }
            catch(Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }
        [HttpPut]
        [Route("{id:guid}")]
        public async Task<IActionResult> UpdateBugAsync([FromRoute] Guid id,
            [FromBody] Infrastructure.Persistence.DTO.UpdateBugRequest updateBugRequest)
        {

            try
            {
                var bug = new Domain.Entities.Bug()
                {
                    BugName = updateBugRequest.BugName,
                    BugDescription = updateBugRequest.BugDescription,

                };


                // Update Region using Service
                bug = await bugService.UpdateAsync(id, bug);


                // If Null then NotFound
                if (bug == null)
                {
                    return NotFound();
                }

                // Convert Domain back to DTO
                //var bugDTO = new Infrastructure.Persistence.DTO.Bug
                //{

                //    BugName = bug.BugName,
                //    BugDescription = bug.BugDescription,
                //    CreatedOn = bug.CreatedOn,
                //    UpdatedOn = bug.UpdatedOn,
                //};


                // Return Ok response
                _logger.LogInfo("Bug Updated ");
              
                return Ok(bug);
            }
            catch(Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }


    }
 }
