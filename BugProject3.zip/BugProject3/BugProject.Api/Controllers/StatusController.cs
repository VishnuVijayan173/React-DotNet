﻿using AutoMapper;
using BugProject.Application.Common.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace BugProject.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class StatusController : Controller
    {
        private readonly IStatusService statusService;
        private readonly IMapper mapper;

        public StatusController(IStatusService statusService, IMapper mapper)
        {
            this.statusService = statusService;
            this.mapper = mapper;
        }
        [HttpGet]

        public async Task<IActionResult> GetAllStatussAsync()
        {
            var statuss = await statusService.GetAllAsync();


            var statussDTO = new List<Infrastructure.Persistence.DTO.Status>();
            statuss.ToList().ForEach(status =>
            {
                var statusDTO = new Infrastructure.Persistence.DTO.Status()
                {
                    StatusID = status.StatusID,
                    BugStatus = status.BugStatus,
                    UpdatedBy = status.UpdatedBy,
                    UpdatedOn = status.UpdatedOn,

                };
                statussDTO.Add(statusDTO);
            });


            return Ok(statussDTO);
        }
        [HttpGet]
        [Route("{id:guid}")]
        [ActionName("GetStatusAsync")]
        public async Task<IActionResult> GetStatusAsync(Guid id)
        {
            var status = await statusService.GetAsync(id);

            if (status == null)
            {
                return NotFound();
            }

            var statuss = await statusService.GetAllAsync();
            var statussDTO = new List<Infrastructure.Persistence.DTO.Status>();
            statuss.ToList().ForEach(status =>
            {
                if (status.StatusID == id)
                {
                    var statusDTO = new Infrastructure.Persistence.DTO.Status()
                    {
                        StatusID = status.StatusID,
                        BugStatus = status.BugStatus,
                        UpdatedBy = status.UpdatedBy,
                        UpdatedOn = status.UpdatedOn,

                    };
                    statussDTO.Add(statusDTO);
                }
            });
            return Ok(statussDTO);
        }

        [HttpPost]

        public async Task<IActionResult> AddStatusAsync(Infrastructure.Persistence.DTO.AddStatusRequest addStatusRequest)
        {

            var status = new Domain.Entities.Status()
            {
                BugStatus= addStatusRequest.BugStatus,
                UpdatedBy = addStatusRequest.UpdatedBy,


                UpdatedOn = addStatusRequest.UpdatedOn,
            };

            // Pass details to Service
            status = await statusService.AddAsync(status);

            // Convert back to DTO

            var statusDTO = new Infrastructure.Persistence.DTO.Status
            {
                StatusID = status.StatusID,
                BugStatus= status.BugStatus,
                UpdatedBy = status.UpdatedBy,

                UpdatedOn = status.UpdatedOn,
            };

            return CreatedAtAction(nameof(GetStatusAsync), new { id = statusDTO.StatusID }, statusDTO);
        }
        [HttpDelete]
        [Route("{id:guid}")]

        public async Task<IActionResult> DeleteStatusAsync(Guid id)
        {
            // Get status from database
            var status = await statusService.DeleteAsync(id);

            // If null NotFound
            if (status == null)
            {
                return NotFound();
            }

            // Convert response back to DTO
            var statusDTO = new Infrastructure.Persistence.DTO.Status
            {
                StatusID = status.StatusID,
                BugStatus= status.BugStatus,
                UpdatedBy = status.UpdatedBy,

                UpdatedOn = status.UpdatedOn,
            };


            return Ok(statusDTO);
        }
        [HttpPut]
        [Route("{id:guid}")]
        public async Task<IActionResult> UpdateStatusAsync([FromRoute] Guid id,
            [FromBody] Infrastructure.Persistence.DTO.UpdateStatusRequest updateStatusRequest)
        {

            var status = new Domain.Entities.Status()
            {
                BugStatus= updateStatusRequest.BugStatus,
                UpdatedBy = updateStatusRequest.UpdatedBy,
                UpdatedOn = updateStatusRequest.UpdatedOn,

            };


            // Update Region using Service
            status = await statusService.UpdateAsync(id, status);


            // If Null then NotFound
            if (status == null)
            {
                return NotFound();
            }

            // Convert Domain back to DTO
            var statusDTO = new Infrastructure.Persistence.DTO.Status
            {
                StatusID = status.StatusID,
                BugStatus= status.BugStatus,
                UpdatedBy = status.UpdatedBy,
                UpdatedOn = status.UpdatedOn,
            };


            // Return Ok response
            return Ok(statusDTO);
        }


    }
}
