﻿using AutoMapper;
using BugProject.Application.Common.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace BugProject.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ProjectController : Controller
    {
        private readonly IProjectService projectService;
        private readonly IMapper mapper;

        public ProjectController(IProjectService projectService, IMapper mapper)
        {
            this.projectService = projectService;
            this.mapper = mapper;
        }
        [HttpGet]

        public async Task<IActionResult> GetAllProjectsAsync()
        {
            var projects = await projectService.GetAllAsync();
            if(projects == null)
            {
                return NoContent();
            }

            var projectsDTO = new List<Infrastructure.Persistence.DTO.Project>();
            projects.ToList().ForEach(project =>
            {
                var projectDTO = new Infrastructure.Persistence.DTO.Project()
                {
                    ProjectID = project.ProjectID,
                    ProjectName = project.ProjectName,
                    ProjectDetails = project.ProjectDetails,
                    UpdatedOn = project.UpdatedOn,
                    UpdatedBy = project.UpdatedBy,

                };
                projectsDTO.Add(projectDTO);
            });


            return Ok(projectsDTO);
        }
        [HttpGet]
        [Route("{id:guid}")]
        [ActionName("GetProjectAsync")]
        public async Task<IActionResult> GetProjectAsync(Guid id)
        {
            var project = await projectService.GetAsync(id);

            if (project == null)
            {
                return NotFound();
            }

            var projects = await projectService.GetAllAsync();
            var projectsDTO = new List<Infrastructure.Persistence.DTO.Project>();
            projects.ToList().ForEach(project =>
            {
                if (project.ProjectID == id)
                {
                    var projectDTO = new Infrastructure.Persistence.DTO.Project()
                    {
                        ProjectID = project.ProjectID,
                        ProjectName = project.ProjectName,
                        ProjectDetails = project.ProjectDetails,
                        UpdatedOn = project.UpdatedOn,
                        UpdatedBy = project.UpdatedBy,

                    };
                    projectsDTO.Add(projectDTO);
                }
            });
            return Ok(projectsDTO);
        }

        [HttpPost]

        public async Task<IActionResult> AddProjectAsync(Infrastructure.Persistence.DTO.AddProjectRequest addProjectRequest)
        {

            var project = new Domain.Entities.Project()
            {
                ProjectName = addProjectRequest.ProjectName,
                ProjectDetails = addProjectRequest.ProjectDetails,
                UpdatedOn = addProjectRequest.UpdatedOn,
                UpdatedBy = addProjectRequest.UpdatedBy,
            };

            // Pass details to Service
            project = await projectService.AddAsync(project);

            // Convert back to DTO

            var projectDTO = new Infrastructure.Persistence.DTO.Project
            {
                ProjectID = project.ProjectID,
                ProjectName = project.ProjectName,
                ProjectDetails = project.ProjectDetails,
                UpdatedOn = project.UpdatedOn,
                UpdatedBy = project.UpdatedBy,
            };

            return CreatedAtAction(nameof(GetProjectAsync), new { id = projectDTO.ProjectID }, projectDTO);
        }
        [HttpDelete]
        [Route("{id:guid}")]

        public async Task<IActionResult> DeleteProjectAsync(Guid id)
        {
            // Get project from database
            var project = await projectService.DeleteAsync(id);

            // If null NotFound
            if (project == null)
            {
                return NotFound();
            }

            // Convert response back to DTO
            var projectDTO = new Infrastructure.Persistence.DTO.Project
            {
                ProjectID = project.ProjectID,
                ProjectName = project.ProjectName,
                ProjectDetails = project.ProjectDetails,
                UpdatedOn = project.UpdatedOn,
                UpdatedBy = project.UpdatedBy,
            };


            // return Ok response
            return Ok(projectDTO);
        }
        [HttpPut]
        [Route("{id:guid}")]
        public async Task<IActionResult> UpdateProjectAsync([FromRoute] Guid id,
            [FromBody] Infrastructure.Persistence.DTO.UpdateProjectRequest updateProjectRequest)
        {

            var project = new Domain.Entities.Project()
            {
                ProjectName = updateProjectRequest.ProjectName,
                ProjectDetails = updateProjectRequest.ProjectDetails,
                UpdatedOn = updateProjectRequest.UpdatedOn,
                UpdatedBy = updateProjectRequest.UpdatedBy,

            };


            // Update Region using Service
            project = await projectService.UpdateAsync(id, project);


            // If Null then NotFound
            if (project == null)
            {
                return NotFound();
            }

            // Convert Domain back to DTO
            var projectDTO = new Infrastructure.Persistence.DTO.Project
            {
                ProjectID = project.ProjectID,
                ProjectName = project.ProjectName,
                ProjectDetails = project.ProjectDetails,
                UpdatedOn = project.UpdatedOn,
                UpdatedBy = project.UpdatedBy,
            };


            // Return Ok response
            return Ok(projectDTO);
        }


    }
}
