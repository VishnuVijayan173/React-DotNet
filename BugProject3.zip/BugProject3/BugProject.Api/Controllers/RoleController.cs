﻿using AutoMapper;
using BugProject.Application.Common.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace BugProject.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class RoleController : Controller
    {
        private readonly IRoleService roleService;
        private readonly IMapper mapper;

        public RoleController(IRoleService roleService, IMapper mapper)
        {
            this.roleService = roleService;
            this.mapper = mapper;
        }
        [HttpGet]

        public async Task<IActionResult> GetAllRolesAsync()
        {
            var roles = await roleService.GetAllAsync();


            var rolesDTO = new List<Infrastructure.Persistence.DTO.Role>();
            roles.ToList().ForEach(role =>
            {
                var roleDTO = new Infrastructure.Persistence.DTO.Role()
                {
                    RoleID = role.RoleID,
                    RoleName = role.RoleName,
                    UpdatedBy= role.UpdatedBy,
                    UpdatedOn = role.UpdatedOn,

                };
                rolesDTO.Add(roleDTO);
            });


            return Ok(rolesDTO);
        }
        [HttpGet]
        [Route("{id:guid}")]
        [ActionName("GetRoleAsync")]
        public async Task<IActionResult> GetRoleAsync(Guid id)
        {
            var role = await roleService.GetAsync(id);

            if (role == null)
            {
                return NotFound();
            }

            var roles = await roleService.GetAllAsync();
            var rolesDTO = new List<Infrastructure.Persistence.DTO.Role>();
            roles.ToList().ForEach(role =>
            {
                if (role.RoleID == id)
                {
                    var roleDTO = new Infrastructure.Persistence.DTO.Role()
                    {
                        RoleID = role.RoleID,
                        RoleName = role.RoleName,
                        UpdatedBy= role.UpdatedBy,
                        UpdatedOn = role.UpdatedOn,

                    };
                    rolesDTO.Add(roleDTO);
                }
            });
            return Ok(rolesDTO);
        }

        [HttpPost]

        public async Task<IActionResult> AddRoleAsync(Infrastructure.Persistence.DTO.AddRoleRequest addRoleRequest)
        {

            var role = new Domain.Entities.Role()
            {
                RoleName = addRoleRequest.RoleName,
                UpdatedBy= addRoleRequest.UpdatedBy,


                UpdatedOn = addRoleRequest.UpdatedOn,
            };

            // Pass details to Service
            role = await roleService.AddAsync(role);

            // Convert back to DTO

            var roleDTO = new Infrastructure.Persistence.DTO.Role
            {
                RoleID = role.RoleID,
                RoleName = role.RoleName,
                UpdatedBy = role.UpdatedBy,

                UpdatedOn = role.UpdatedOn,
            };

            return CreatedAtAction(nameof(GetRoleAsync), new { id = roleDTO.RoleID }, roleDTO);
        }
        [HttpDelete]
        [Route("{id:guid}")]

        public async Task<IActionResult> DeleteRoleAsync(Guid id)
        {
            // Get role from database
            var role = await roleService.DeleteAsync(id);

            // If null NotFound
            if (role == null)
            {
                return NotFound();
            }

            // Convert response back to DTO
            var roleDTO = new Infrastructure.Persistence.DTO.Role
            {
                RoleID = role.RoleID,
                RoleName = role.RoleName,
                UpdatedBy = role.UpdatedBy,

                UpdatedOn = role.UpdatedOn,
            };


            // return Ok response
            return Ok(roleDTO);
        }
        [HttpPut]
        [Route("{id:guid}")]
        public async Task<IActionResult> UpdateRoleAsync([FromRoute] Guid id,
            [FromBody] Infrastructure.Persistence.DTO.UpdateRoleRequest updateRoleRequest)
        {

            var role = new Domain.Entities.Role()
            {
                RoleName = updateRoleRequest.RoleName,
                UpdatedBy = updateRoleRequest.UpdatedBy,
                UpdatedOn = updateRoleRequest.UpdatedOn,

            };


            // Update Region using Service
            role = await roleService.UpdateAsync(id, role);


            // If Null then NotFound
            if (role == null)
            {
                return NotFound();
            }

            // Convert Domain back to DTO
            var roleDTO = new Infrastructure.Persistence.DTO.Role
            {
                RoleID = role.RoleID,
                RoleName = role.RoleName,
                UpdatedBy = role.UpdatedBy,
                UpdatedOn = role.UpdatedOn,
            };


            // Return Ok response
            return Ok(roleDTO);
        }


    }
}
