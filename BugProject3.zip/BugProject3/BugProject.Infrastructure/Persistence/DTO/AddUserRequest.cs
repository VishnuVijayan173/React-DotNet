﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Infrastructure.Persistence.DTO
{
    public class AddUserRequest
    {
        public Guid UserID { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }

        public Guid RoleID { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedOn { get; set; }
    }
}
