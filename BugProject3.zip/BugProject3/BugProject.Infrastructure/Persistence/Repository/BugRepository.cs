﻿using BugProject.Application.Common.Interfaces;
using BugProject.Domain.Entities;
using BugProject.Domain.Repositories;
using BugProject.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace BugProject.Infrastructure.Persistence.Repository
{
    public class BugRepository : Repository<Bug>, IBugRepository
    {
        private readonly IUnitOfWork _unitOfWork;
        public BugRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            this._unitOfWork = unitOfWork;
        }
    }
}