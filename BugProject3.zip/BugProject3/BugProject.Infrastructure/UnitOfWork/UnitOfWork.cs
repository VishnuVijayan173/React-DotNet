﻿using BugProject.Application.Common.Interfaces;
using BugProject.Infrastructure.Persistence.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Infrastructure.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly AppDbContext _context;
        private readonly Dictionary<Type, object> _repositories = new Dictionary<Type, object>(); public UnitOfWork(AppDbContext context)
        {
            _context = context;
        }
        public AppDbContext Context
        {
            get { return _context; }
        }
        public async Task<int> CommitAsync()
        {
            using (var transaction = _context.Database.BeginTransaction())
            {
                try
                {
                    var result = await _context.SaveChangesAsync();
                    transaction.Commit();   
                    return result;
                }
                catch (Exception)
                {
                    //This implementation ensures that either all changes are saved to the database or
                    //none of them are, avoiding partial updates to the database in case of exceptions.
                    Console.WriteLine("Failed");
                    transaction.Rollback();
                    throw;
                }
            }
        }
        public void Dispose()
        {
            //  throw new NotImplementedException();
        }
    }
}
