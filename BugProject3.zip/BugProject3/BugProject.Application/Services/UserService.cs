﻿using BugProject.Application.Common.Interfaces;
using BugProject.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Application.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository userRepository;
        public UserService(IUserRepository userRepository)
        {
            this.userRepository = userRepository;
        }
        public async Task<IEnumerable<Domain.Entities.User>> GetAllAsync()
        {
            return await userRepository.GetAllAsync();
        }
        public async Task<Domain.Entities.User> GetAsync(Guid id)
        {
            return await userRepository.GetAsync(id);
        }
        public async Task<Domain.Entities.User> AddAsync(Domain.Entities.User user)
        {
            return await userRepository.AddAsync(user);
        }
        public async Task<Domain.Entities.User> DeleteAsync(Guid id)
        {
            return await userRepository.DeleteAsync(id);
        }
        public async Task<Domain.Entities.User> UpdateAsync(Guid id, Domain.Entities.User user)
        {
            return await userRepository.UpdateAsync(id, user);
        }
    }
}
