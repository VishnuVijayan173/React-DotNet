﻿using AutoMapper;

namespace Project1._0.Profiles
{
    public class BugProfile : Profile
    {
        public BugProfile()
        {
            CreateMap<Models.Domain.Bug, Models.DTO.Bug>()
                .ReverseMap();

        }
    }
}
