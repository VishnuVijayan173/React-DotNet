﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Identity.Client;
using Project1._0.Models.Domain;
using Project1._0.Models.DTO;
using Project1._0.Repositories;
namespace Project1._0.Controllers
{
    [ApiController]
    [Route("user")]
    public class UserController : Controller
    {
        private readonly IUserRepository userRepository;
        private readonly IMapper mapper;

        public UserController(IUserRepository userRepository, IMapper mapper)
        {
            this.userRepository = userRepository;
            this.mapper = mapper;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllUsers()
        {
            var users = await userRepository.GetAllAsync();
            var usersDTO= mapper.Map<Models.DTO.User>(users);

            return Ok(usersDTO);
        }
        [HttpGet]
        [Route("{id:guid}")]
        [ActionName("GetUserAsync")]
        public async Task<IActionResult> GetUserAsync(Guid id)
        {
            var user = userRepository.GetAsync(id);
            if(user == null)
            {
                return NotFound();
            }
            var userDTO = mapper.Map<Models.DTO.User>(user);
            return Ok(userDTO);
        }
        [HttpPost]
        public async Task<IActionResult> AddUserAsync(Models.DTO.AddUserRequest addUserRequest)
        {
            var user = new Models.Domain.User()
            {
                UserName = addUserRequest.UserName,
                Password = addUserRequest.Password,
                RoleID = addUserRequest.RoleID,
                UpdatedBy = addUserRequest.UpdatedBy,
                UpdatedOn = addUserRequest.UpdatedOn,
            };
            user = await userRepository.AddAsync(user);

            var userDTO = new Models.DTO.User
            {
                UserID = user.UserID,
                UserName = user.UserName,
                Password = user.Password,
                RoleID = (Guid)user.RoleID,
                UpdatedBy = (Guid)user.UpdatedBy,
                UpdatedOn = user.UpdatedOn,
            };
            return CreatedAtAction(nameof(GetUserAsync), new { userDTO.UserID }, userDTO);
        }

        [HttpDelete]
        [Route("{id:guid}")]
        public async Task<IActionResult> DeleteUserAsync(Guid id)
        {
            var user= await userRepository.DeleteAsync(id);
            if(user == null)
            {
                return NotFound();
            }
            var userDTO = new Models.DTO.User
            {
                UserID = user.UserID,
                UserName = user.UserName,
                Password = user.Password,
                RoleID = (Guid)user.RoleID,
                UpdatedBy = (Guid)user.UpdatedBy,
                UpdatedOn = user.UpdatedOn,
            };
            return Ok(userDTO);

        }
        [HttpPut]
        [Route("{id:guid}")]
        public async Task<IActionResult> UpdateUserAsync([FromRoute]Guid id,[FromBody] Models.DTO.UpdateUserRequest updateUserRequest)
        {
            var user = new Models.Domain.User()
            {
                UserName = updateUserRequest.UserName,
                Password = updateUserRequest.Password,
                UpdatedBy = updateUserRequest.UpdatedBy,
                UpdatedOn = updateUserRequest.UpdatedOn,
            };
            user = await userRepository.UpdateAsync(id, user);
            if(user == null)
            {
                return NotFound();
            }
            var userDTO = new Models.DTO.User
            {
                UserID = user.UserID,
                UserName = user.UserName,
                Password = user.Password,
                RoleID = (Guid)user.RoleID,
                UpdatedBy = (Guid)user.UpdatedBy,
                UpdatedOn = user.UpdatedOn,
            };
            return Ok(userDTO);

        }
    }
}
