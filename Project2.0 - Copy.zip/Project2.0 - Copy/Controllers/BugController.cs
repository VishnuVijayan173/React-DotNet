﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Project1._0.Repositories;

namespace Project1._0.Controllers
{
    [ApiController]
    [Route("bug")]
    public class BugController : Controller
    {
        private readonly IBugRepository bugRepository;
        private readonly IMapper mapper;

        public BugController(IBugRepository bugRepository, IMapper mapper)
        {
            this.bugRepository = bugRepository;
            this.mapper = mapper;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllBugs()
        {
            var bugs = await bugRepository.GetAllAsync();
            // return DTO regions
            var bugssDTO = new List<Models.DTO.Bug>();
            bugs.ToList().ForEach(region =>
            {
                var regionDTO = new Models.DTO.Bug()
                {
                    BugID = region.BugID,
                    BugDescription = region.BugDescription,
                    ugName = region.Name,
                    Area = region.Area,
                    Lat = region.Lat,
                    Long = region.Long,
                    Population = region.Population,
                };

                regionsDTO.Add(regionDTO);
            });

            return Ok(bugsDTO);
        }
        [HttpGet]
        [Route("{id:guid}")]
        [ActionName("GetBugAsync")]
        //public async Task<IActionResult> GetBugAsync(Guid id)
        //{
        //    var bug = bugRepository.GetAsync(id);
        //    if (bug == null)
        //    {
        //        return NotFound();
        //    }
        //    var bugDTO = mapper.Map<Models.DTO.Bug>(bug);
        //    return Ok(bugDTO);
        //}
        [HttpPost]
        public async Task<IActionResult> AddBugAsync(Models.DTO.AddBugRequest addBugRequest)
        {
            var bug = new Models.Domain.Bug()
            {
                BugName = addBugRequest.BugName,
                BugDescription = addBugRequest.BugDescription,
                StatusID = addBugRequest.StatusID,
                ProjectID = addBugRequest.ProjectID,
                CreatedOn= addBugRequest.CreatedOn,
                RaisedBy= addBugRequest.RaisedBy,
                AssignedTo= addBugRequest.AssignedTo,
                UpdatedBy = addBugRequest.UpdatedBy,
                UpdatedOn = addBugRequest.UpdatedOn,
            };
            bug = await bugRepository.AddAsync(bug);

            var bugDTO = new Models.DTO.Bug
            {
                BugID = bug.BugID,
                BugName = bug.BugName,
                BugDescription= bug.BugDescription,
                StatusID = (Guid)bug.StatusID,
                ProjectID = (Guid)bug.ProjectID,
                CreatedOn= bug.CreatedOn,
                RaisedBy= (Guid)bug.RaisedBy,
                AssignedTo= (Guid)bug.AssignedTo,
                UpdatedBy = (Guid)bug.UpdatedBy,
                UpdatedOn = bug.UpdatedOn,
            };
            return CreatedAtAction(nameof(GetBugAsync), new { bugDTO.BugID }, bugDTO);
        }

        [HttpDelete]
        [Route("{id:guid}")]
        public async Task<IActionResult> DeleteBugAsync(Guid id)
        {
            var bug = await bugRepository.DeleteAsync(id);
            if (bug == null)
            {
                return NotFound();
            }
            var bugDTO = new Models.DTO.Bug
            {
                BugID = bug.BugID,
                BugName = bug.BugName,
                BugDescription = bug.BugDescription,
                StatusID= (Guid)bug.StatusID,
                ProjectID= (Guid)bug.ProjectID,
                CreatedOn = bug.CreatedOn,
                RaisedBy= (Guid)bug.RaisedBy,
                AssignedTo= (Guid)bug.AssignedTo,
                UpdatedBy = (Guid)bug.UpdatedBy,
                UpdatedOn = bug.UpdatedOn,
            };
            return Ok(bugDTO);

        }
        [HttpPut]
        [Route("{id:guid}")]
        public async Task<IActionResult> UpdateBugAsync([FromRoute] Guid id, [FromBody] Models.DTO.UpdateBugRequest updateBugRequest)
        {
            var bug = new Models.Domain.Bug()
            {
                BugName = updateBugRequest.BugName,
                BugDescription = updateBugRequest.BugDescription,
                StatusID = updateBugRequest.StatusID,    
                AssignedTo= updateBugRequest.AssignedTo,
                UpdatedBy = updateBugRequest.UpdatedBy,
                UpdatedOn = updateBugRequest.UpdatedOn,
            };
            bug = await bugRepository.UpdateAsync(id, bug);
            if (bug == null)
            {
                return NotFound();
            }
            var bugDTO = new Models.DTO.Bug
            {
                BugID = bug.BugID,
                BugName = bug.BugName,
                BugDescription = bug.BugDescription,
                StatusID = (Guid)bug.StatusID,
                ProjectID = (Guid)bug.ProjectID,
                CreatedOn= bug.CreatedOn,
                RaisedBy= (Guid)bug.RaisedBy,
                AssignedTo= (Guid)bug.AssignedTo,
                UpdatedBy = (Guid)bug.UpdatedBy,
                UpdatedOn = bug.UpdatedOn,
            };
            return Ok(bugDTO);

        }
    }
}
