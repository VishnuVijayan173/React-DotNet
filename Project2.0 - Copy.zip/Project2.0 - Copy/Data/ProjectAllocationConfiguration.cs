﻿//using Microsoft.EntityFrameworkCore.Metadata.Builders;
//using Microsoft.EntityFrameworkCore;
//using Project1._0.Models.Domain;

//namespace Project1._0.Data
//{
//    public class ProjectAllocationConfiguration : IEntityTypeConfiguration<ProjectAllocation>
//    {
//        public void Configure(EntityTypeBuilder<ProjectAllocation> builder)
//        {
//            builder.HasKey(pa => pa.AllocationID);
//            builder.HasOne(pa => pa.Project).WithMany(p => p.ProjectAllocation).HasForeignKey(pa => pa.ProjectID);
//            builder.HasOne(pa => pa.User).WithMany().HasForeignKey(pa => pa.UserID);
//            builder.Property(pa => pa.UpdatedOn).IsRequired();
//            builder.Property(pa => pa.UpdatedBy).IsRequired();
//        }
//    }
//}
