﻿//using Microsoft.EntityFrameworkCore.Metadata.Builders;
//using Microsoft.EntityFrameworkCore;
//using Project1._0.Models.Domain;

//namespace Project1._0.Data
//{
//    public class RoleConfiguration :IEntityTypeConfiguration<Role>
//    {
//        public void Configure(EntityTypeBuilder<Role> builder)
//    {
//        builder.HasKey(x => x.RoleID);
//        builder.Property(x => x.RoleName).IsRequired().HasMaxLength(100);
//        builder.HasOne(x => x.User).WithMany().HasForeignKey(x => x.UpdatedBy).OnDelete(DeleteBehavior.Restrict);
//    }
//}
//}
