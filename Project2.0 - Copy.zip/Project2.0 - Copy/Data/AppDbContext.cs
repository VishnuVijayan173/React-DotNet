﻿using Project1._0.Models.Domain;
using Microsoft.EntityFrameworkCore;



namespace Project1._0.Models.Domain
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }

        public DbSet<Bug> Bugs { get; set; }
        public DbSet<Project> Projects { get; set; }
        public DbSet<ProjectAllocation> ProjectAllocation { get; set; }
        public DbSet<Role> Role { get; set; }
        public DbSet<Status> Statuses { get; set; }
        public DbSet<User> Users { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>(entity =>
            {
                entity.ToTable("User");
                entity.HasKey(e => e.UserID);
                entity.Property(e => e.UserName)
                .IsRequired()
                .HasMaxLength(50);
                entity.Property(e => e.Password)
                .IsRequired()
                .HasMaxLength(50);
                entity.HasOne(d => d.Role)
                      .WithMany()
                      .HasForeignKey(d => d.RoleID)
                      .OnDelete(DeleteBehavior.NoAction)
                      .HasConstraintName("FK_User_Role");
            });

            modelBuilder.Entity<Role>(entity =>
            {
                entity.ToTable("Role");
                entity.HasKey(e => e.RoleID);
                entity.Property(e => e.RoleName)
                      .IsRequired()
                      .HasMaxLength(50);
            });

            modelBuilder.Entity<Status>(entity =>
            {
                entity.ToTable("Status");
                entity.HasKey(e => e.StatusID);
                entity.Property(e => e.BugStatus)
                .IsRequired()
                .HasMaxLength(50);
                entity.HasOne(d => d.User)
                      .WithMany()
                      .HasForeignKey(d => d.UpdatedBy)
                      .OnDelete(DeleteBehavior.NoAction)
                      .HasConstraintName("FK_Status_User");
            });

            modelBuilder.Entity<Bug>(entity =>
            {
                entity.ToTable("Bug");
                entity.HasKey(e => e.BugID);
                entity.Property(e => e.BugName)
                .IsRequired()
                .HasMaxLength(50);
                entity.Property(e => e.BugDescription)
                .IsRequired()
                .HasMaxLength(500);
                entity.HasOne(d => d.Status)
                .WithMany(p => p.Bug)
                .HasForeignKey(d => d.StatusID)
                .OnDelete(DeleteBehavior.NoAction)
                .HasConstraintName("FK_Bug_Status");
                entity.HasOne(d => d.Project)
                .WithMany(p => p.Bug)
                .HasForeignKey(d => d.ProjectID)
                .OnDelete(DeleteBehavior.NoAction)
                .HasConstraintName("FK_Bug_Project");
                entity.HasOne(d => d.User)
                      .WithMany(p => p.Bug)
                      .HasForeignKey(d => d.AssignedTo)
                      .OnDelete(DeleteBehavior.NoAction)
                      .HasConstraintName("FK_Bug_User");
                entity.HasOne(d => d.User)
                .WithMany(p => p.Bug)
                .HasForeignKey(d => d.UpdatedBy)
                .OnDelete(DeleteBehavior.NoAction)
                .HasConstraintName("FK_Bug_User1");
            });
            modelBuilder.Entity<Project>(entity =>
            {
                entity.ToTable("Project");
                entity.HasKey(e => e.ProjectID);
                entity.Property(e => e.ProjectName)
                .IsRequired()
                .HasMaxLength(50);
                entity.Property(e => e.ProjectDetails)
                .IsRequired()
                .HasMaxLength(500);
            });

            modelBuilder.Entity<ProjectAllocation>(entity =>
            {
                entity.ToTable("ProjectAllocation");
                entity.HasKey(e => e.AllocationID);
                entity.HasOne(d => d.User)
                .WithMany(p => p.ProjectAllocation)
                .HasForeignKey(d => d.UserID)
                .OnDelete(DeleteBehavior.NoAction)
                .HasConstraintName("FK_ProjectAllocation_User");
                entity.HasOne(d => d.Project)
                .WithMany(p => p.ProjectAllocation)
                .HasForeignKey(d => d.ProjectID)
                .OnDelete(DeleteBehavior.NoAction)
                .HasConstraintName("FK_ProjectAllocation_Project");
            });
        }
    }
}
    


