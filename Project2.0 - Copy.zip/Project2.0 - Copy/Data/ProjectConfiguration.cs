﻿//using Microsoft.EntityFrameworkCore.Metadata.Builders;
//using Microsoft.EntityFrameworkCore;
//using Project1._0.Models.Domain;

//namespace Project1._0.Data
//{
//    public class ProjectConfiguration : IEntityTypeConfiguration<Project>
//    {
//        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<Project> builder)
//        {
//            builder.ToTable("Project");
//            builder.HasKey(p => p.ProjectID);
//            builder.Property(p => p.ProjectName).HasMaxLength(100).IsRequired();
//            builder.Property(p => p.ProjectDetails).HasMaxLength(500).IsRequired();
//            builder.HasOne(p => p.User).WithMany().HasForeignKey(p => p.UpdatedBy);
//            builder.Property(p => p.UpdatedOn).HasDefaultValueSql("GETDATE()");
//        }
//    }
//}
