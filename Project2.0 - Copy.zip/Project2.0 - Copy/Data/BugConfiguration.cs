﻿//using Microsoft.EntityFrameworkCore.Metadata.Builders;
//using Microsoft.EntityFrameworkCore;
//using Project1._0.Models.Domain;

//namespace Project1._0.Data
//{
//    public class BugConfiguration : IEntityTypeConfiguration<Bug>
//    {
//        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<Bug> builder)
//        {
//            builder.ToTable("Bug");
//            builder.HasKey(b => b.BugID);
//            builder.Property(b => b.BugName).HasMaxLength(100).IsRequired();
//            builder.Property(b => b.BugDescription).HasMaxLength(500).IsRequired();
//            builder.HasOne(b => b.Status).WithMany(s => s.Bug).HasForeignKey(b => b.StatusID);
//            builder.HasOne(b => b.Project).WithMany(p => p.Bug).HasForeignKey(b => b.ProjectID);
//            builder.HasOne(b => b.User).WithMany().HasForeignKey(b => b.RaisedBy);
//            builder.HasOne(b => b.User).WithMany().HasForeignKey(b => b.AssignedTo);
//            builder.HasOne(b => b.User).WithMany().HasForeignKey(b => b.UpdatedBy);
//            builder.Property(b => b.CreatedOn).HasDefaultValueSql("GETDATE()");
//            builder.Property(b => b.UpdatedOn).HasDefaultValueSql("GETDATE()");
//        }
//    }
//}
