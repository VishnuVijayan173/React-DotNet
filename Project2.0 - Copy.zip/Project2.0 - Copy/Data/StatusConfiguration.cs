﻿//using Microsoft.EntityFrameworkCore.Metadata.Builders;
//using Microsoft.EntityFrameworkCore;
//using Project1._0.Models.Domain;

//namespace Project1._0.Data
//{
//    public class StatusConfiguration : IEntityTypeConfiguration<Status>
//    {
//        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<Status> builder)
//        {
//            builder.ToTable("Status");
//            builder.HasKey(s => s.StatusID);
//            builder.Property(s => s.BugStatus).HasMaxLength(100).IsRequired();
//            builder.Property(s => s.UpdatedOn).HasDefaultValueSql("GETDATE()");
//            builder.HasOne(s => s.User).WithMany().HasForeignKey(s => s.UpdatedBy);
//            builder.HasMany(s => s.Bug).WithOne(b => b.Status).HasForeignKey(b => b.StatusID);
//        }
//    }
//}
