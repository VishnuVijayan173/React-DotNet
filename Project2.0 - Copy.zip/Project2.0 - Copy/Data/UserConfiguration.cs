﻿//using Microsoft.EntityFrameworkCore.Metadata.Builders;
//using Microsoft.EntityFrameworkCore;
//using Project1._0.Models.Domain;

//namespace Project1._0.Data
//{
//    public class UserConfiguration: IEntityTypeConfiguration<User>
//    {
//        public void Configure(EntityTypeBuilder<User> builder)
//        { 
           
//        builder.HasKey(x => x.UserID);
//        builder.Property(x => x.UserName).IsRequired().HasMaxLength(100);
//        builder.Property(x => x.Password).IsRequired().HasMaxLength(100);
//        builder.HasOne(x => x.Role).WithMany().HasForeignKey(x => x.RoleID).OnDelete(DeleteBehavior.Restrict);
//        builder.HasMany(x => x.ProjectAllocation).WithOne(x => x.User).HasForeignKey(x => x.UserID).OnDelete(DeleteBehavior.Restrict);
//        builder.HasMany(x => x.Bug).WithOne(x => x.User).HasForeignKey(x => x.RaisedBy).OnDelete(DeleteBehavior.Restrict);
//        builder.HasMany(x => x.Project).WithOne(x => x.User).HasForeignKey(x => x.UpdatedBy).OnDelete(DeleteBehavior.Restrict);
//        }
//    }
//}

