﻿namespace Project1._0.Models.DTO
{
    public class UpdateUserRequest
    {
        public string UserName { get; set; }
        public string Password { get; set; }

        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedOn { get; set; }
    }
}
