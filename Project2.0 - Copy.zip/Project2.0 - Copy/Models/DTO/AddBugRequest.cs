﻿namespace Project1._0.Models.DTO
{
    public class AddBugRequest
    {
        public Guid BugID { get; set; }
        public string BugName { get; set; }
        public string BugDescription { get; set; }
        public Guid StatusID { get; set; }
        public Guid ProjectID { get; set; }
        public DateTime CreatedOn { get; set; }
        public Guid RaisedBy { get; set; }
        public Guid AssignedTo { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedOn { get; set; }
    }
}
