﻿namespace Project1._0.Models.DTO
{
    public class AddUserRequest
    {
        public string UserName { get; set; }
        public string Password { get; set; }

        public Guid RoleID { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedOn { get; set; }
    }
}
