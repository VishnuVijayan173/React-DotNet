﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project1._0.Models.Domain
{
    public class Bug
    {
        [Key]
        public Guid BugID { get; set; }
        public string BugName { get; set; }
        public string BugDescription { get; set; }
        public Nullable<Guid> StatusID { get; set; }
        public Nullable<Guid> ProjectID { get; set; }
        public DateTime CreatedOn { get; set; }
        public Nullable<Guid> RaisedBy { get; set; }
        public Nullable<Guid> AssignedTo { get; set; }
        public Nullable<Guid> UpdatedBy { get; set; }
        public DateTime UpdatedOn { get; set; }

        [ForeignKey("StatusID")]
        public Status Status { get; set; }
        [ForeignKey("ProjectID")]
        public Project Project { get; set; }
        [ForeignKey("UserID")]
        public User User { get; set; }

       





    }
}
