﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project1._0.Models.Domain
{
    public class Status
    {
        [Key]
        public Guid StatusID { get; set; }
        public string BugStatus { get; set; }
        public DateTime UpdatedOn { get; set; }
       
        public Nullable<Guid> UpdatedBy { get; set; }
        [ForeignKey("UserID")]
        public User User { get; set; } 
        public IEnumerable<Bug> Bug { get; set; }

        


    }
}
