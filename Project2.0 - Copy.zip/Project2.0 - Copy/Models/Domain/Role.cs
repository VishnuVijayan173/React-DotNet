﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project1._0.Models.Domain
{
    public class Role
    {
        [Key]
        public Guid RoleID { get; set; }
        public string RoleName { get; set; }
     
        public Nullable<Guid> UserID { get; set; }
        public DateTime UpdatedOn { get; set; }
        //[ForeignKey("UserID")]
        //public User User { get; set; }

        public IEnumerable<User> Users { get; set;}
    }
}
