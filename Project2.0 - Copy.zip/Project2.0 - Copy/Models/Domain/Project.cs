﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project1._0.Models.Domain
{
    public class Project
    {
        [Key]
        public Guid ProjectID { get; set; }
        public string ProjectName { get; set; }
        public string ProjectDetails { get; set; }
        public DateTime UpdatedOn { get; set; }
        public Nullable<Guid> UpdatedBy { get; set; }

        [ForeignKey("UserID")]
        public User User { get; set; }


        public IEnumerable<ProjectAllocation> ProjectAllocation { get; set;}
        public IEnumerable<Bug> Bug { get; set; }
    }
}
