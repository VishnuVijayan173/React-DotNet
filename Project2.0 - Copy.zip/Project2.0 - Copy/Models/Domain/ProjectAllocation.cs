﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project1._0.Models.Domain
{
    public class ProjectAllocation
    {
        [Key]
        public Guid AllocationID { get; set; }
      
        public Nullable<Guid> ProjectID { get; set; }
      
        public Nullable<Guid> UserID { get; set; }
        public DateTime UpdatedOn { get; set; }
   
        public string UpdatedBy { get; set; }

        [ForeignKey("ProjectID")]
        public Project Project { get; set; }
        [ForeignKey("UserID")]
        public User User { get; set; }
    }
}
