﻿namespace Project1._0.Repositories
{
    public class BaseRepository
    {
    }
}
