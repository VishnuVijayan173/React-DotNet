﻿using Microsoft.EntityFrameworkCore;
using Project1._0.Models.Domain;


namespace Project1._0.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly AppDbContext appDbContext;

        public UserRepository(AppDbContext appDbContext)
        {
            this.appDbContext = appDbContext;
        }

        public async Task<User> AddAsync(User user)
        {
            user.UserID = Guid.NewGuid();
            await appDbContext.AddAsync(user);
            await appDbContext.SaveChangesAsync();
            return user;

        }

        public async Task<IEnumerable<User>> GetAllAsync()
        {
            return await appDbContext.Users.ToListAsync();
        }

        public async Task<User> GetAsync(Guid UserId)
        {
            return await appDbContext.Users.FirstOrDefaultAsync(x => x.UserID == UserId);
        }
        public async Task<User> DeleteAsync(Guid UserId)
        {
            var user = await appDbContext.Users.FirstOrDefaultAsync(x => x.UserID == UserId);
            if (user == null)
            {
                return user;
            }
            appDbContext.Users.Remove(user);
            appDbContext.SaveChangesAsync();
            return user;
        }

        public async Task<User> UpdateAsync(Guid id, User user)
        {
            var existingUser = await appDbContext.Users.FirstOrDefaultAsync(x => x.UserID == id);
            if (user == null)
            {
                return null;
            }
            existingUser.UserName = user.UserName;
            existingUser.Password = user.Password;

            await appDbContext.SaveChangesAsync();
            return existingUser;

        }
    }
}
