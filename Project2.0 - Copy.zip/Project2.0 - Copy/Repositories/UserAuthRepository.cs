﻿using Microsoft.EntityFrameworkCore;
using Project1._0.Models.Domain;

namespace Project1._0.Repositories
{
    public class UserAuthRepository : IUserAuthRepository
    {
        private List<User> Users = new List<User>()
        {
            new User()
            {
                UserID = Guid.NewGuid(), UserName = "readonly@user.com", Password = "Readonly@user",
                
            },
            new User()
            {
                UserID = Guid.NewGuid(), UserName = "readwrite@user.com", Password = "Readwrite@user",
                
            }
        };



        public async Task<User> AuthenticateAsync(string username, string password)
        {
            var user = Users.Find(x => x.UserName.Equals(username, StringComparison.InvariantCultureIgnoreCase) &&
            x.Password == password);

            return user;
        }
    }          
        
}
