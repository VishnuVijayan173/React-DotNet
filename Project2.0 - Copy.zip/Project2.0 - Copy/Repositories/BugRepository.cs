﻿using Microsoft.EntityFrameworkCore;
using Project1._0.Models.Domain;

namespace Project1._0.Repositories
{
    public class BugRepository : IBugRepository
    {
        private readonly AppDbContext appDbContext;

        public BugRepository(AppDbContext appDbContext)
        {
            this.appDbContext = appDbContext;
        }

        public async Task<Bug> AddAsync(Bug bug)
        {
            bug.BugID = Guid.NewGuid();
            await appDbContext.AddAsync(bug);
            await appDbContext.SaveChangesAsync();
            return bug;

        }

        public async Task<IEnumerable<Bug>> GetAllAsync()
        {
            return await appDbContext.Bugs.ToListAsync();
        }

        public async Task<Bug> GetAsync(Guid BugId)
        {
            return await appDbContext.Bugs.FirstOrDefaultAsync(x => x.BugID == BugId);
        }
        public async Task<Bug> DeleteAsync(Guid BugId)
        {
            var bug = await appDbContext.Bugs.FirstOrDefaultAsync(x => x.BugID == BugId);
            if (bug == null)
            {
                return bug;
            }
            appDbContext.Bugs.Remove(bug);
            appDbContext.SaveChangesAsync();
            return bug;
        }

        public async Task<Bug> UpdateAsync(Guid id, Bug bug)
        {
            var existingBug = await appDbContext.Bugs.FirstOrDefaultAsync(x => x.BugID == id);
            if (bug == null)
            {
                return null;
            }
            existingBug.BugName = bug.BugName;
            existingBug.BugDescription = bug.BugDescription;
            existingBug.StatusID= bug.StatusID;
            existingBug.UpdatedOn = bug.UpdatedOn;
            existingBug.AssignedTo = bug.AssignedTo;
            existingBug.UpdatedBy = bug.UpdatedBy;



            await appDbContext.SaveChangesAsync();
            return existingBug;

        }
    }
}
