﻿using Project1._0.Models.Domain;

namespace Project1._0.Repositories
{
    public interface IUserAuthRepository
    {
        Task<User> AuthenticateAsync(string userName, string password);
    }
}
