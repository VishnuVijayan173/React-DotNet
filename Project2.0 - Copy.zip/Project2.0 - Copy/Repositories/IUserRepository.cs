﻿using Project1._0.Models.Domain;

namespace Project1._0.Repositories
{
    public interface IUserRepository
    {
        Task <IEnumerable<User>> GetAllAsync();

        Task<User> GetAsync(Guid UserID);

        Task<User> AddAsync(User user);

        Task<User> DeleteAsync(Guid UserID);

        Task<User> UpdateAsync(Guid id,User user);
    }
}
