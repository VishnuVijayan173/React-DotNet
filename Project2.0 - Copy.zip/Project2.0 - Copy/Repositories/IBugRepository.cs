﻿using Project1._0.Models.Domain;

namespace Project1._0.Repositories
{
    public interface IBugRepository
    {
        Task<IEnumerable<Bug>> GetAllAsync();

        Task<Bug> GetAsync(Guid BugID);

        Task<Bug> AddAsync(Bug bug);

        Task<Bug> DeleteAsync(Guid BugID);

        Task<Bug> UpdateAsync(Guid id, Bug bug);
    }
}
