﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Domain.Entities
{
    public class User
    {
        public Guid UserID { get; set; }
        public string UserName { get; set; }
        public string EmailAddress { get; set; }
        public string Password { get; set; }

        public Nullable<Guid> UpdatedBy { get; set; }
      
        public DateTime UpdatedOn { get; set; }
        

        public IEnumerable<ProjectAllocation> ProjectAllocation { get; set; }
        public IEnumerable<Project> Project { get; set; }
        public IEnumerable<Bug> Bug { get; set; }
        public IEnumerable<User_Role> user_Roles { get; set; }
    }
}
