﻿
using System.ComponentModel.DataAnnotations.Schema;

namespace BugProject.Domain.Entities
{
    public class Bug
    {
        public Guid BugID { get; set; }
        public string BugName { get; set; }
        public string BugDescription { get; set; }
        public Nullable<Guid> StatusID { get; set; }
        public Nullable<Guid> AllocationID { get; set; }
        public DateTime CreatedOn { get; set; }
        public Nullable<Guid> RaisedBy { get; set; }
        public Nullable<Guid> AssignedTo { get; set; }
        public Nullable<Guid> UpdatedBy { get; set; }
      
        public DateTime UpdatedOn { get; set; }
        [ForeignKey("StatusID")]
        public Status status { get; set; }
        [ForeignKey("UserID")]
        public User user { get; set; }
        [ForeignKey("AllocationID")]
        public ProjectAllocation projectAllocation { get; set; }
    }
}
