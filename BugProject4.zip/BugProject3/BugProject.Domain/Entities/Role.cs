﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Domain.Entities
{
    public class Role
    {
        public Guid RoleID { get; set; }
        public string RoleName { get; set; }

        public Nullable<Guid> UpdatedBy { get; set; }
        public DateTime UpdatedOn { get; set; }
       public IEnumerable<User_Role> user_Roles { get; set;}


    }
}
