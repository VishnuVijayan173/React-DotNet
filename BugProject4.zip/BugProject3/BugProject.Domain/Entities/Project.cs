﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Domain.Entities
{
    public class Project
    {
        public Guid ProjectID { get; set; }
        public string ProjectName { get; set; }
        public string ProjectDetails { get; set; }
        public DateTime UpdatedOn { get; set; }
        public Nullable<Guid> UpdatedBy { get; set; }
        [ForeignKey("UserID")]
        public User user { get;set; }


        public IEnumerable<ProjectAllocation> ProjectAllocation { get; set; }
       
    }
}
