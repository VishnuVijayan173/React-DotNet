﻿using BugProject.Application.Common.Interfaces;
using BugProject.Application.Common.Logger;
using BugProject.Application.Services;
using BugProject.Domain.Entities;
using BugProject.Infrastructure.Persistence.DTO;
using Microsoft.AspNetCore.Mvc;

namespace BugProject.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class User_RoleController : Controller
    {
        private readonly IUser_RoleService user_RoleService;
        private readonly ILoggerManager _logger;


        public User_RoleController(IUser_RoleService user_RoleService, ILoggerManager logger)
        {
            this.user_RoleService = user_RoleService;
            this._logger = logger;

        }
        [HttpGet]

        public async Task<IActionResult> GetAllUser_RolesAsync()
        {
            try
            {
                var roles = await user_RoleService.GetAllAsync();
                
                    _logger.LogInfo(message:" UserRoles Retrieved ");
                
                return Ok(roles);
            }


            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpGet]
        [Route("{id:guid}")]
        [ActionName("GetUser_RoleAsync")]
        public async Task<IActionResult> GetUser_RoleAsync(Guid id)
        {
            try
            {
                var role = await user_RoleService.GetAsync(id);

                if (role == null)
                {
                    _logger.LogInfo("The recod was not found ");
                    return NotFound();
                }

                var roles = await user_RoleService.GetAllAsync();
                var user_RolesDTO = new List<Infrastructure.Persistence.DTO.User_Role>();
                roles.ToList().ForEach(role =>
                {
                    if (role.Id == id)
                    {
                        var user_RoleDTO = new Infrastructure.Persistence.DTO.User_Role()
                        {
                            Id = role.Id,
                            UserID = role.UserID,
                            RoleID = role.RoleID,

                        };
                        user_RolesDTO.Add(user_RoleDTO);
                        _logger.LogInfo("User Roles Retrieved with id ");
                    }
                });

                return Ok(user_RolesDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]

        public async Task<IActionResult> AddUserRoleAsync(Infrastructure.Persistence.DTO.AddUser_RoleRequest addUser_RoleRequest)
        {
            try
            {


                var role = new Domain.Entities.User_Role()
                {
                    UserID = addUser_RoleRequest.UserID,
                    RoleID = addUser_RoleRequest.RoleID,
                };


                // Pass details to Service
                role = await user_RoleService.AddAsync(role);


                // Convert back to DTO


                _logger.LogInfo("User Role Added ");

                return Ok(CreatedAtAction(nameof(GetUser_RoleAsync), new { id = role.Id }, role));
            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }

        }
        [HttpDelete]
        [Route("{id:guid}")]

        public async Task<IActionResult> DeleteBugAsync(Guid id)
        {
            try
            {
                // Get Bug from database
                var role = await user_RoleService.DeleteAsync(id);

                // If null NotFound
                if (role == null)
                {
                    return NotFound();
                }

                // Convert response back to DTO


                // return Ok response
                _logger.LogInfo("Bug Deleted ");

                return Ok(role);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }
        [HttpPut]
        [Route("{id:guid}")]
        public async Task<IActionResult> UpdateUser_RoleAsync([FromRoute] Guid id,
            [FromBody] Infrastructure.Persistence.DTO.UpdateUser_RoleRequest updateUser_RoleRequest)
        {

            try
            {
                var role = new Domain.Entities.User_Role()
                {
                    UserID = updateUser_RoleRequest.UserID,
                    RoleID = updateUser_RoleRequest.RoleID,

                };


                // Update Region using Service
                role = await user_RoleService.UpdateAsync(id, role);


                // If Null then NotFound
                if (role == null)
                {
                    return NotFound();
                }

                // Convert Domain back to DTO
                //var bugDTO = new Infrastructure.Persistence.DTO.Bug
                //{

                //    BugName = bug.BugName,
                //    BugDescription = bug.BugDescription,
                //    CreatedOn = bug.CreatedOn,
                //    UpdatedOn = bug.UpdatedOn,
                //};


                // Return Ok response
                _logger.LogInfo("Bug Updated ");

                return Ok(role);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }
    }
    }
