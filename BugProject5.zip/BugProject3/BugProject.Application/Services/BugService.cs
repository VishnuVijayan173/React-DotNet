﻿using BugProject.Application.Common.Interfaces;
using BugProject.Domain.Entities;
using BugProject.Domain.Repositories;
using BugProject.Infrastructure.Persistence.DTO;
using BugProject.Infrastructure.Persistence.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BugProject.Application.Services
{
    

    public class BugService :IBugService
    {

        
        private readonly IBugRepository bugRepository;
        public BugService(IBugRepository bugRepository)
        {
            this.bugRepository = bugRepository;
            

        }
        public async Task<IEnumerable<Domain.Entities.Bug>> GetAllAsync()
        {

            return await bugRepository.GetAllAsync();
        }
        public async Task<Domain.Entities.Bug> GetAsync(Guid id)
        {
            return await bugRepository.GetAsync(id);
        }
        public async Task<Domain.Entities.Bug> AddAsync(Domain.Entities.Bug bug)
        {
            
            return await bugRepository.AddAsync(bug);
         
        }
        public async Task<Domain.Entities.Bug> DeleteAsync(Guid id)
        {
            return await bugRepository.DeleteAsync(id);
        }
        public async Task<Domain.Entities.Bug> UpdateAsync(Guid id, Domain.Entities.Bug bug)
        {
            return await bugRepository.UpdateAsync(id, bug);
        }
    }
     
}
