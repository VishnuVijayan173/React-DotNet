﻿using BugProject.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Application.Common.Interfaces
{
    public interface IProjectService
    {
        Task<IEnumerable<Project>> GetAllAsync();

        Task<Project> GetAsync(Guid id);

        Task<Project> AddAsync(Project project);

        Task<Project> DeleteAsync(Guid id);

        Task<Project> UpdateAsync(Guid id, Project project);
    }
}
