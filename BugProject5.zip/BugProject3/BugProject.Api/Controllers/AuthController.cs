﻿using Microsoft.AspNetCore.Mvc;

namespace BugProject.Api.Controllers
{
    public class AuthController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
