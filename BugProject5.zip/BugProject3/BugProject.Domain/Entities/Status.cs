﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Domain.Entities
{
    public class Status
    {
        public Guid StatusID { get; set; }
        public string BugStatus { get; set; }
        public DateTime UpdatedOn { get; set; }

        public Nullable<Guid> UpdatedBy { get; set; }
        [ForeignKey("UserID")]

        public User user { get;set; }
        public IEnumerable<Bug> Bug { get; set; }
    }
}
