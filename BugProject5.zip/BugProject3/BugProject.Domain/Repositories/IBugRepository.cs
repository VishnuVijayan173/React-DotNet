﻿using BugProject.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BugProject.Domain.Repositories
{
    public interface IBugRepository : IRepository<Bug>
    {
       
    }
}
