﻿using BugProject.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Domain.Repositories
{
    public interface IRoleRepository : IRepository<Role>
    {

      
    }
}
