﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Infrastructure.Persistence.DTO
{
    public class User_Role
    {
        public Guid Id { get; set; }

        public Guid UserID { get; set; }
        [ForeignKey("UserID")]
        public User user { get; set; }

        public Guid RoleID { get; set; }
        [ForeignKey("RoleID")]
        public Role role { get; set; }
    }
}
