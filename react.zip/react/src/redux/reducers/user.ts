import { AnyAction } from 'redux';
import { LOGIN } from '../actions/types';
import { AppState } from '../store';

export interface IUserReducer {
    username: string,
    token:string
}

export const userReducerInit: IUserReducer = {
    username: '',
    token: ''
};

const userReducer = (state = userReducerInit, action: AnyAction): AppState => {
    switch (action.type) {
        case LOGIN:
            // return{
            //     username:action.payload.username,
            //     token:action.payload.token
            // };
            return action.payload;
    }
    return state;
};

export default userReducer;
