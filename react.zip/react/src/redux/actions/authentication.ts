import { AnyAction, Dispatch } from 'redux';
import { LOGIN } from './types';
import { handleError } from '../../utils/handle-error';
import axios from '../../utils/interceptors';

export const loginApi = (data:any) => async (dispatch: Dispatch<AnyAction>) => {
    try {
        const response = await axios.post('http://localhost:4000/login', {
        username : data.username,
        password : data.password
    });
        dispatch({
            type: LOGIN,
            payload: response.data,
        });
        return response.data.data;
    } catch (err: any) {
        handleError(err);
    }
};