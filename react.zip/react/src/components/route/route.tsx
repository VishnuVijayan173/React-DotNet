import React from 'react';
import { Route, Routes } from 'react-router-dom';
import BugList from '../../pages/User/BugsList/BugsList';
import Dashboard from '../../pages/User/Dashboard/Dashboard';
import Home from '../../pages/User/Home/Home';
import { LogicalOrCoalescingAssignmentOperator } from 'typescript';
import Login from '../../pages/User/Login/Login';
const AppRoutes = () => {
    return (
        <Routes>
            <Route path='/' element={<div>Hello User!!</div>} />
            <Route path='/login' element={<Login/>} />
            <Route path="/dashboard" element={<Dashboard/>} >
              <Route index element= {<Home/>}/>
              <Route path='bugs' element= {<BugList/>}/>
            </Route>
        </Routes>
    );
};

export default AppRoutes;
