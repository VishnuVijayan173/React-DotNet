export const envVariables: any = {
    apiUrl: 'apiUrl',
    apimSubscriptionKey: 'subscription key',
    authUrl: 'authUrl',
};
