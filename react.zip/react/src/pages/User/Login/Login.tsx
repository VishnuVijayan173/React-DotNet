import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { Link, Navigate } from 'react-router-dom';
import { AppState, useAppThunkDispatch } from '../../../redux/store';
import './Login.css';

const Login = () => {
    const [userName, setUserName]= useState('');
    const [password, setPassword]= useState('');
    const dispatch = useAppThunkDispatch();
  const user = useSelector((state: AppState) => state.login);
  // eslint-disable-next-line no-console
  console.log('User ',user);
  const submit =(e:any)=>{
     e.preventDefault();
    dispatch(LoginApi({
      userName,password
    }));
  };

    return(

      <div className="Auth-form-container">
        <form className="Auth-form " >
          <div className="Auth-form-content">
            <h3 className="Auth-form-title">Login</h3>
            <div className="form-group mt-3">
              <label>UserName</label>
              <input
                type="text"
                className="form-control mt-1"
                placeholder="Enter username"
                onChange={(e) => {
                  setUserName(e.target.value);
                }}
              />
            </div>
            <div className="form-group mt-3">
              <label>Password</label>
              <input
                type="password"
                className="form-control mt-1"
                placeholder="Enter password"
                onChange={(e) => {
                  setPassword(e.target.value);
                }}
              />
            </div>
            <div className="d-grid gap-2 mt-3">
              <button   type="submit" className="btn btn-primary">
                Submit
              </button>
            </div>
            <p></p>
          </div>
        </form>
      </div>
    );
            };


