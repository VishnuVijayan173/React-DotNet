import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { Link, Navigate } from 'react-router-dom';
import { text } from 'stream/consumers';
import Input from '../../../components/app/input/input';
import { loginApi } from '../../../redux/actions/authentication';
import { AppState, useAppThunkDispatch } from '../../../redux/store';
import './Login.css';

const Login = () => {
    const [username, setUserName]= useState('');
    const [password, setPassword]= useState('');
    const dispatch = useAppThunkDispatch();

    const Handleclick =(e: any)=> {
      e.preventDEfault();
      // eslint-disable-next-line no-console
      console.log('Event:', username,password);
      dispatch(loginApi({
        username,password
      }));
    };


  const user = useSelector((state: AppState) => state.login);
  // eslint-disable-next-line no-console
  console.log('User ',user);


    return(

      <div className="Auth-form-container">
        <form className="Auth-form " >
          <div className="Auth-form-content">
            <h3 className="Auth-form-title">Login</h3>
            <div className="form-group mt-3">
              <label>UserName</label>
              <Input value={username} onChange={setUserName} type='text'/>
            </div>
            <div className="form-group mt-3">
              <label>Password</label>
              <Input value={password} onChange={setPassword} type='password'/>
            </div>
            <div className="d-grid gap-2 mt-3">
              <button   type="submit" className="btn btn-primary">
                Submit
              </button>
            </div>
            <p></p>
          </div>
        </form>
      </div>
    );
            };
export default Login;


