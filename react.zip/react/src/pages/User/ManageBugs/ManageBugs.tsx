import React, { useEffect, useState } from 'react';
import { Table, ButtonToolbar } from 'react-bootstrap';
import { FaEdit } from 'react-icons/fa';
import { RiDeleteBin5Line } from 'react-icons/ri';
//import AddBugModal from './AddBugModal';
import axios from 'axios';
//import { GetBugs } from '../services/BugServices';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { toast, ToastContainer } from 'react-toastify';
import { useNavigate } from 'react-router-dom';


const ManageBugs = () => {
  const [data, setData] = useState([]);
  const [addModalShow, setAddModalShow] = useState(false);
  const [isUpdated, setIsUpdated] = useState(false);
  const [show, setShow] = useState(false);



  const [editBugId, setEditBugId] = useState();
  const [editBugName, setEditBugName] = useState('');
  const [editBugDescription, setEditBugDescription] = useState('');
  const [editBugStatus, setEditBugStatus] = useState('');
  const [editProject, setEditProject] = useState('');
  const [editRaisedBy, setEditRaisedBy] = useState('');

  const navigate = useNavigate();

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);




  useEffect(() => {
    axios.get('https://localhost:44306/api/Bug')
      .then(res => setData(res.data))
      // eslint-disable-next-line no-console
      .catch(err => console.log(err));
  }, []);


  //let AddModelClose = () => setAddModalShow(false);
  return (
    <div className="container-fluid side-container">
      <ToastContainer />
      <div className="row side-row">
        <p id="manage"></p>
        <Table striped bordered hover className="react-bootstrap-table" id="dataTable">
          <thead>
            <tr>
              <th >BugID</th>
              <th>Bug Name</th>
              <th>Bug Description</th>
              <th>Bug Satus</th>
              <th>Project</th>
              <th>Raised By</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
                <td>
                  <Button className="mr-2" variant="danger">
                    <RiDeleteBin5Line />
                  </Button>
                  <span>&nbsp;&nbsp;&nbsp;</span>
                  <Button className="mr-2" >
                    <FaEdit />
                  </Button>

                </td>
          </tbody>

        </Table>
        <ButtonToolbar>
          <Button variant="primary" >
            Add Bug
          </Button>
          <AddBugModal show={addModalShow} setUpdated={setIsUpdated}
            onHide={AddModelClose}></AddBugModal>
        </ButtonToolbar>
        <Modal show={show} onHide={handleClose}>
          <Modal.Header closeButton>
            <Modal.Title>Edit details</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="container">
              <div>
                <label>Bug Name</label>
                <input type="text" className="form-control" placeholder="Enter BugName"
                  value={editBugName} onChange={(e) => setEditBugName(e.target.value)}
                />
              </div>
              <div>
                <label>Bug Description</label>
                <input type="text" className="form-control" placeholder="Enter description"
                  value={editBugDescription} onChange={(e) => setEditBugDescription(e.target.value)}
                />
              </div>
              <div>
                <label>Bug Status</label>
                <input type="text" className="form-control" placeholder="Enter Status"
                  value={editBugStatus} onChange={(e) => setEditBugStatus(e.target.value)}
                />
              </div>
              <div>
                <label>Project</label>
                <input type="text" className="form-control" placeholder="Enter Project"
                  value={editProject} onChange={(e) => setEditProject(e.target.value)}
                />
              </div>
              <div>
                <label>Raised By</label>
                <input type="text" className="form-control" placeholder="Raised By"
                  value={editRaisedBy} onChange={(e) => setEditRaisedBy(e.target.value)}
                />
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
            <Button variant="primary" value={editBugId} >
              Save Changes
            </Button>
          </Modal.Footer>
        </Modal>
      </div>
    </div>
  );
};

export default ManageBugs;