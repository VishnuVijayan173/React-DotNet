import React from 'react';
import { Table } from 'react-bootstrap';
import './BugsList.css';

const BugList = () => {
    return (
        <>
      <div className="container-fluid side-container">
      <div className="row " >
       <p id="before-table"></p>
           <Table striped bordered hover className="react-bootstrap-table" id="dataTable">
           <thead>
               <tr>
               <th>BugID</th>
               <th>Bug Name</th>
               <th>Bug Description</th>
               <th>Bug Status</th>
               <th>Project</th>
               <th>Raised By</th>
               </tr>
           </thead>
           <tbody>
           </tbody>
       </Table>
       </div>
       <div className="row side-row">
      <input
        type="text"
        placeholder="Search..."
        onChange={e => (e.target.value)}
      />
      <button >Search</button>
    </div>
     </div>
        </>
    );
};
export default BugList;
